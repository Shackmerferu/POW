import { listarProductos, insertarProducto } from './api.js';
import { mostrarProductos } from './mostrar.js';
import { leerEnteroPositivo, leerNumeroPositivo } from './ui.js';

const formAgregar = document.getElementById('form-agregar');
const modCodigo = document.getElementById('mod_codigo');
const modNombre = document.getElementById('mod_nombre');
const modCantidad = document.getElementById('mod_cantidad');
const modPrecio = document.getElementById('mod_precio');
const modMinima = document.getElementById('mod_minima');
const modImagen = document.getElementById('mod_imagen');
const btnGuardar = document.getElementById('btn-guardar-nuevo');

async function guardarProducto() {
    const codigo = leerEnteroPositivo(modCodigo);
    const nombre = modNombre.value.trim();
    const cantidad = leerEnteroPositivo(modCantidad);
    const precio = leerNumeroPositivo(modPrecio);
    const minima = leerEnteroPositivo(modMinima);

    if (codigo === null) {
        return alert('El Código debe ser un número positivo');
    }
    if (nombre === '') {
        return alert('La descripción es obligatoria');
    }
    if (cantidad === null) {
        return alert('La cantidad debe ser un número positivo');
    }
    if (precio === null) {
        return alert('El precio de costo debe ser un número positivo');
    }
    if (minima === null) {
        return alert('La cantidad mínima debe ser un número positivo');
    }

    try {
        // La API original no informa duplicados al insertar, así que se controla
        // comparando el código ingresado con el ID y con el código de cada producto.
        const datos = await listarProductos();
        const productos = datos.status === 200 && Array.isArray(datos.productos)
            ? datos.productos
            : [];

        const existente = productos.some((producto) =>
            Number(producto.id) === codigo || Number(producto.codigo) === codigo
        );

        if (existente) {
            return alert('El producto ya existe en la base de datos');
        }

        const respuesta = await insertarProducto({
            codigo,
            nombre,
            cantidad,
            precio_costo: precio,
            cantidad_minima: minima
        }, modImagen.files[0] || null);

        if (respuesta.status === 200) {
            alert('El producto fue guardado correctamente');

            formAgregar.reset();

            const modal = window.bootstrap.Modal.getOrCreateInstance(
                document.getElementById('modalAgregar')
            );
            modal.hide();

            // El enunciado pide mostrar los productos una vez guardado.
            await mostrarProductos();
        } else if (respuesta.status === 505) {
            alert('El producto ya existe en la base de datos');
        } else {
            alert(respuesta.menssage || 'No se pudo guardar el producto');
        }
    } catch (error) {
        alert(error.message);
    }
}

export function inicializarAgregar() {
    btnGuardar.addEventListener('click', guardarProducto);

    formAgregar.addEventListener('submit', (evento) => {
        evento.preventDefault();
        guardarProducto();
    });
}
