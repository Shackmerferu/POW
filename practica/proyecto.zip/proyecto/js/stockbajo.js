import { listarProductos } from './api.js';
import {
    renderTabla,
    mostrarMensaje,
    mostrarContador,
    limpiarContador,
    ocultarTabla
} from './ui.js';

/** Muestra los productos cuya cantidad es igual o inferior a la cantidad mínima. */
export async function mostrarStockBajo() {
    try {
        const datos = await listarProductos();

        // La API original devuelve status 500 cuando la tabla está vacía.
        const tablaVacia = datos.status === 500 && !Array.isArray(datos.productos);
        if (datos.status !== 200 && !tablaVacia) {
            throw new Error(datos.menssage || 'No se pudieron obtener los productos');
        }

        const productos = Array.isArray(datos.productos) ? datos.productos : [];

        const stockBajo = productos
            .filter((producto) => Number(producto.cantidad) <= Number(producto.cantidad_minima))
            .sort((a, b) => String(a.nombre).localeCompare(String(b.nombre), 'es', {
                sensitivity: 'base'
            }));

        mostrarMensaje('Productos por debajo de la cantidad mínima');
        renderTabla(stockBajo, { conValor: false });
        mostrarContador(`Cantidad de productos: ${stockBajo.length}`);
    } catch (error) {
        mostrarMensaje(error.message);
        ocultarTabla();
        limpiarContador();
    }
}

export function inicializarStockBajo() {
    document.getElementById('btn-stock-bajo').addEventListener('click', mostrarStockBajo);
}
