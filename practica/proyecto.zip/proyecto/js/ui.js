// Referencias a los elementos del DOM
export const inputCodigo = document.getElementById('codigo');
export const inputCantidad = document.getElementById('cantidad');
export const inputPrecio = document.getElementById('precio');

export const mensajeSistema = document.getElementById('mensaje-sistema');
export const contenedorTabla = document.getElementById('tabla-container');
export const tablaCabecera = document.getElementById('tabla-cabecera');
export const tablaCuerpo = document.getElementById('tabla-cuerpo');
export const contadorProductos = document.getElementById('contador-productos');

const formatoNumero = new Intl.NumberFormat('es-AR', {
    useGrouping: false,
    maximumFractionDigits: 2
});

/** Escapa el texto para poder insertarlo dentro del HTML de la tabla. */
function escaparHtml(valor) {
    return String(valor ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#39;');
}

/** Devuelve un entero positivo o null si el campo no es válido. */
export function leerEnteroPositivo(input) {
    const valor = input.value.trim();

    if (valor === '' || !/^\d+$/.test(valor)) {
        return null;
    }

    const numero = Number(valor);
    return numero > 0 ? numero : null;
}

/** Devuelve un número positivo (admite decimales) o null si no es válido. */
export function leerNumeroPositivo(input) {
    const valor = input.value.trim();

    if (valor === '') {
        return null;
    }

    const numero = Number(valor);
    return Number.isFinite(numero) && numero > 0 ? numero : null;
}

export function mostrarMensaje(texto) {
    mensajeSistema.textContent = texto;
}

export function limpiarMensaje() {
    mostrarMensaje('');
}

export function mostrarContador(texto) {
    contadorProductos.textContent = texto;
    contadorProductos.classList.remove('oculto');
}

export function limpiarContador() {
    contadorProductos.textContent = '';
    contadorProductos.classList.add('oculto');
}

export function ocultarTabla() {
    contenedorTabla.classList.add('oculto');
    tablaCabecera.innerHTML = '';
    tablaCuerpo.innerHTML = '';
}

/** Devuelve la celda con la miniatura del producto o un guion si no tiene imagen. */
function renderImagen(producto) {
    if (!producto.imagen) {
        return '<td><span class="sin-imagen">—</span></td>';
    }

    const ruta = `api_almacen/imagenes/${encodeURIComponent(producto.imagen)}`;

    return `<td><img src="${escaparHtml(ruta)}" alt="Imagen de ${escaparHtml(producto.nombre)}" class="miniatura"></td>`;
}

/**
 * Dibuja la tabla de productos.
 * @param {Array} productos lista de productos
 * @param {{conValor?: boolean}} opciones conValor indica si se muestra la columna Valor $$
 */
export function renderTabla(productos, { conValor = true } = {}) {
    if (!Array.isArray(productos) || productos.length === 0) {
        ocultarTabla();
        return;
    }

    tablaCabecera.innerHTML = conValor
        ? '<tr><th>ID</th><th>Nombre</th><th>Cant</th><th>Precio $</th><th>cant mínima</th><th>Valor $$</th><th>Imagen</th></tr>'
        : '<tr><th>ID</th><th>Nombre</th><th>Cant</th><th>Precio</th><th>cant mínima</th><th>Imagen</th></tr>';

    tablaCuerpo.innerHTML = productos.map((producto) => {
        const cantidad = Number(producto.cantidad);
        const precio = Number(producto.precio_costo);
        const valorStock = cantidad * precio;

        const celdas = [
            `<td>${escaparHtml(producto.id)}</td>`,
            `<td>${escaparHtml(producto.nombre)}</td>`,
            `<td>${escaparHtml(cantidad)}</td>`,
            `<td>${escaparHtml(formatoNumero.format(precio))}</td>`,
            `<td>${escaparHtml(producto.cantidad_minima)}</td>`
        ];

        if (conValor) {
            celdas.push(`<td>${escaparHtml(formatoNumero.format(valorStock))}</td>`);
        }

        celdas.push(renderImagen(producto));

        return `<tr>${celdas.join('')}</tr>`;
    }).join('');

    contenedorTabla.classList.remove('oculto');
}
