import { obtenerProducto, borrarProducto } from './api.js';
import { mostrarProductos } from './mostrar.js';
import {
    inputCodigo,
    leerEnteroPositivo,
    mostrarMensaje,
    limpiarMensaje,
    contenedorTabla
} from './ui.js';

/** BORRAR: elimina de la base de datos el producto indicado en el formulario. */
export async function borrar() {
    limpiarMensaje();

    const codigo = leerEnteroPositivo(inputCodigo);

    if (codigo === null) {
        return mostrarMensaje('El Código (ID) debe ser un número positivo');
    }

    try {
        const producto = await obtenerProducto(codigo);

        if (!producto) {
            return mostrarMensaje('Código inexistente');
        }

        // La API original borra por el campo `codigo`, no por el ID.
        const respuesta = await borrarProducto(producto.codigo);

        if (respuesta.status === 200) {
            const tablaVisible = !contenedorTabla.classList.contains('oculto');

            mostrarMensaje('Eliminado');

            if (tablaVisible) {
                await mostrarProductos();
                mostrarMensaje('Eliminado');
            }
        } else if (respuesta.status === 505) {
            mostrarMensaje('Código inexistente');
        } else {
            mostrarMensaje(respuesta.menssage || 'No se pudo eliminar el producto');
        }
    } catch (error) {
        mostrarMensaje(error.message);
    }
}

export function inicializarBorrar() {
    document.getElementById('btn-borrar').addEventListener('click', borrar);
}
