import { obtenerProducto, modificarProducto } from './api.js';
import {
    inputCodigo,
    inputCantidad,
    leerEnteroPositivo,
    mostrarMensaje,
    limpiarMensaje
} from './ui.js';

/**
 * BAJA: descuenta stock de un producto existente (venta, rotura, etc.).
 */
export async function baja() {
    limpiarMensaje();

    const codigo = leerEnteroPositivo(inputCodigo);
    const cantidad = leerEnteroPositivo(inputCantidad);

    if (codigo === null) {
        return mostrarMensaje('El Código (ID) debe ser un número positivo');
    }
    if (cantidad === null) {
        return mostrarMensaje('La cantidad debe ser un número positivo');
    }

    try {
        const producto = await obtenerProducto(codigo);

        if (!producto) {
            return mostrarMensaje('Código inexistente');
        }

        const stockActual = Number(producto.cantidad);

        if (cantidad > stockActual) {
            return mostrarMensaje(`La cantidad a retirar es superior al Stock(${stockActual})`);
        }

        const respuesta = await modificarProducto({
            ...producto,
            cantidad: stockActual - cantidad
        });

        if (respuesta.status === 200) {
            mostrarMensaje('Actualizado');
        } else if (respuesta.status === 505) {
            mostrarMensaje('Código inexistente');
        } else {
            mostrarMensaje(respuesta.menssage || 'No se pudo actualizar el producto');
        }
    } catch (error) {
        mostrarMensaje(error.message);
    }
}

export function inicializarBaja() {
    document.getElementById('btn-baja').addEventListener('click', baja);
}
