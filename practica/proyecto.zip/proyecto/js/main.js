import { inicializarAlta } from './alta.js';
import { inicializarBaja } from './baja.js';
import { inicializarAgregar } from './agregar.js';
import { inicializarBorrar } from './borrar.js';
import { inicializarMostrar } from './mostrar.js';
import { inicializarStockBajo } from './stockbajo.js';

document.addEventListener('DOMContentLoaded', () => {
    inicializarAlta();
    inicializarBaja();
    inicializarAgregar();
    inicializarBorrar();
    inicializarMostrar();
    inicializarStockBajo();

    // El formulario principal no se envía: los botones manejan las acciones.
    document.getElementById('form-principal').addEventListener('submit', (evento) => {
        evento.preventDefault();
    });
});
