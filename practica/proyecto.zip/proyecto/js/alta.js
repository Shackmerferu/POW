import { obtenerProducto, modificarProducto } from './api.js';
import {
    inputCodigo,
    inputCantidad,
    inputPrecio,
    leerEnteroPositivo,
    leerNumeroPositivo,
    mostrarMensaje,
    limpiarMensaje
} from './ui.js';

/**
 * ALTA: ingresa mercadería a un producto existente.
 * Actualiza la cantidad y recalcula el precio de costo por Precio Promedio Ponderado.
 */
export async function alta() {
    limpiarMensaje();

    const codigo = leerEnteroPositivo(inputCodigo);
    const cantidad = leerEnteroPositivo(inputCantidad);
    const precio = leerNumeroPositivo(inputPrecio);

    if (codigo === null) {
        return mostrarMensaje('El Código (ID) debe ser un número positivo');
    }
    if (cantidad === null) {
        return mostrarMensaje('La cantidad debe ser un número positivo');
    }
    if (precio === null) {
        return mostrarMensaje('El precio debe ser un número positivo');
    }

    try {
        const producto = await obtenerProducto(codigo);

        if (!producto) {
            return mostrarMensaje('Código inexistente');
        }

        const stockActual = Number(producto.cantidad);
        const precioActual = Number(producto.precio_costo);
        const nuevoStock = stockActual + cantidad;

        // Precio Promedio Ponderado:
        // (stock actual * precio actual + cantidad ingresada * precio ingresado) / nuevo stock
        const nuevoPrecio = Math.round(
            ((stockActual * precioActual) + (cantidad * precio)) / nuevoStock
        );

        const respuesta = await modificarProducto({
            ...producto,
            cantidad: nuevoStock,
            precio_costo: nuevoPrecio
        });

        if (respuesta.status === 200) {
            mostrarMensaje('Actualizado');
        } else if (respuesta.status === 505) {
            mostrarMensaje('Código inexistente');
        } else {
            mostrarMensaje(respuesta.menssage || 'No se pudo actualizar el producto');
        }
    } catch (error) {
        mostrarMensaje(error.message);
    }
}

export function inicializarAlta() {
    document.getElementById('btn-alta').addEventListener('click', alta);
}
