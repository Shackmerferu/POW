const API_URL = 'api_almacen/almacen_api.php';

/**
 * Realiza una petición GET a la API y devuelve el JSON recibido.
 */
async function pedir(parametros = {}) {
    const url = new URL(API_URL, window.location.href);

    Object.entries(parametros).forEach(([clave, valor]) => {
        if (valor !== undefined && valor !== null && valor !== '') {
            url.searchParams.set(clave, valor);
        }
    });

    let respuesta;
    try {
        respuesta = await fetch(url, { headers: { Accept: 'application/json' } });
    } catch (error) {
        throw new Error('No se pudo conectar con el servidor');
    }

    if (!respuesta.ok) {
        throw new Error(`Error HTTP ${respuesta.status}`);
    }

    try {
        return await respuesta.json();
    } catch (error) {
        throw new Error('La API devolvió una respuesta inválida');
    }
}

/** Devuelve todos los productos (o uno solo si se pasa el código/ID). */
export function listarProductos(codigo) {
    return pedir(codigo === undefined ? {} : { codigo });
}

/** Devuelve el producto cuyo ID coincide con el código, o null si no existe. */
export async function obtenerProducto(codigo) {
    // La API original busca por ID con el parámetro `codigo`.
    const datos = await pedir({ codigo });

    if (datos.status === 200 && Array.isArray(datos.productos) && datos.productos.length > 0) {
        return datos.productos[0];
    }

    // Si no existe ese ID, se busca por el campo `codigo` del producto.
    // Así también funcionan los productos nuevos, cuyo ID es automático.
    const todos = await pedir({});

    if (todos.status === 200 && Array.isArray(todos.productos)) {
        const encontrado = todos.productos.find(
            (producto) => Number(producto.codigo) === Number(codigo)
        );

        if (encontrado) {
            return encontrado;
        }
    }

    return null;
}

/** Actualiza un producto existente enviando todos sus campos. */
export function modificarProducto(producto) {
    return pedir({
        action: 'modificar',
        id: producto.id,
        codigo: producto.codigo,
        nombre: producto.nombre,
        cantidad: producto.cantidad,
        precio_costo: producto.precio_costo,
        cantidad_minima: producto.cantidad_minima
    });
}

/**
 * Inserta un producto nuevo usando la misma acción `insertar` de la API.
 * Se envía por POST con FormData para poder incluir la imagen.
 * @param {object} producto datos del producto
 * @param {File|null} imagen archivo de imagen (opcional)
 */
export async function insertarProducto(producto, imagen = null) {
    const datos = new FormData();
    datos.append('action', 'insertar');
    datos.append('codigo', producto.codigo);
    datos.append('nombre', producto.nombre);
    datos.append('cantidad', producto.cantidad);
    datos.append('precio_costo', producto.precio_costo);
    datos.append('cantidad_minima', producto.cantidad_minima);

    if (imagen) {
        datos.append('imagen', imagen);
    }

    let respuesta;
    try {
        // No se define Content-Type: el navegador agrega el boundary de multipart.
        respuesta = await fetch(API_URL, {
            method: 'POST',
            body: datos,
            headers: { Accept: 'application/json' }
        });
    } catch (error) {
        throw new Error('No se pudo conectar con el servidor');
    }

    if (!respuesta.ok) {
        throw new Error(`Error HTTP ${respuesta.status}`);
    }

    try {
        return await respuesta.json();
    } catch (error) {
        throw new Error('La API devolvió una respuesta inválida');
    }
}

/** Elimina el producto indicado. */
export function borrarProducto(codigo) {
    return pedir({ action: 'borrar', codigo });
}
