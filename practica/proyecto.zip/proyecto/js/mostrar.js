import { listarProductos } from './api.js';
import {
    renderTabla,
    mostrarMensaje,
    limpiarMensaje,
    limpiarContador,
    ocultarTabla
} from './ui.js';

/** Trae todos los productos y los muestra ordenados por nombre ascendente. */
export async function mostrarProductos() {
    try {
        const datos = await listarProductos();

        // La API original devuelve status 500 cuando la tabla está vacía.
        const tablaVacia = datos.status === 500 && !Array.isArray(datos.productos);
        if (datos.status !== 200 && !tablaVacia) {
            throw new Error(datos.menssage || 'No se pudieron obtener los productos');
        }

        const productos = Array.isArray(datos.productos) ? datos.productos : [];

        if (productos.length === 0) {
            mostrarMensaje('No hay productos cargados');
            ocultarTabla();
            limpiarContador();
            return;
        }

        productos.sort((a, b) => String(a.nombre).localeCompare(String(b.nombre), 'es', {
            sensitivity: 'base'
        }));

        limpiarMensaje();
        limpiarContador();
        renderTabla(productos, { conValor: true });
    } catch (error) {
        mostrarMensaje(error.message);
        ocultarTabla();
        limpiarContador();
    }
}

export function inicializarMostrar() {
    document.getElementById('btn-mostrar').addEventListener('click', mostrarProductos);
}
